"""Generate competition predictions from the saved Model 11 checkpoints."""
import os
os.environ.setdefault('OMP_NUM_THREADS','4')
os.environ.setdefault('OPENBLAS_NUM_THREADS','4')
import sys
from pathlib import Path
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parents[2]/'tmp/abhay_deps'))
import argparse,json,hashlib,warnings
import numpy as np
import pandas as pd
import joblib,cv2
from threadpoolctl import threadpool_limits
import dalvin_core as b
import data_protocol as p
import verifier as v


def submission_frame(sample,test,train,order_ids,pred):
    if not sample.id.is_unique or set(sample.id)!=set(test.id):
        raise ValueError('Sample submission IDs do not match test.csv')
    frame=pd.DataFrame({'id':order_ids,'predictions':[' '.join(row) for row in pred]})
    if not frame.id.is_unique or set(frame.id)!=set(test.id):
        raise ValueError('Predictions do not cover every test ID exactly once')
    result=sample[['id']].merge(frame,on='id',how='left',validate='one_to_one')
    species=test.set_index('id').species
    allowed=train.groupby('species').identity.apply(set).to_dict()
    for row in result.itertuples(index=False):
        labels=row.predictions.split()
        if len(labels)!=5 or len(set(labels))!=5:raise ValueError('Need five distinct labels')
        if any(label!='new_individual' and label not in allowed[species[row.id]] for label in labels):
            raise ValueError('Invalid identity or cross-species prediction')
    assert result.id.tolist()==sample.id.tolist()
    return result


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--data',type=Path,required=True)
    ap.add_argument('--sample',type=Path,required=True)
    ap.add_argument('--run',type=Path,required=True)
    ap.add_argument('--workers',type=int,default=4)
    args=ap.parse_args();run=args.run
    config=json.loads((run/'config.json').read_text())
    for name in ('verifier.py','dalvin_core.py','data_protocol.py'):
        if hashlib.sha256((HERE/name).read_bytes()).hexdigest()!=config['sources'][name]:
            raise ValueError(f'{name} changed since training; restore the training source snapshot')
    models=joblib.load(run/'baseline_models.joblib')
    if len(models)!=3:raise ValueError('Baseline training has not completed all three stages')
    network=joblib.load(run/'verifier.joblib')
    calibrators=joblib.load(run/'calibrators.joblib')
    cv2.setNumThreads(1)
    warnings.filterwarnings('ignore',message='Only one sample available.*',category=UserWarning)
    train,test,meta=p.load_data(args.data);b.NX=b.X
    sample=pd.read_csv(args.sample)
    if not sample.id.is_unique or set(sample.id)!=set(test.id):raise ValueError('Wrong sample submission file')
    # All labelled photos are now gallery; every test photo is an unlabelled query.
    # Role-local caches are reselected for this full population by activate().
    cache=p.SiftCache(args.data,run,args.workers,150)
    print('Preparing full-gallery SIFT. This can take substantially longer than validation.',flush=True)
    cache.activate(np.arange(len(meta)))
    gi=np.arange(len(train));qi=np.arange(len(train),len(meta))
    s=p.frame(gi,qi);s,r=p.through_stack(s,models)
    print('Computing verifier evidence against full labelled gallery',flush=True)
    _,features=v.query_features(network,b.X,b.Y,gi,s,r)
    pnew=.5*(r['pb']+calibrators['mlp'].predict_proba(features)[:,1])
    candidates=s['c'].ident.to_numpy().reshape(-1,15)
    for name,score in [('mlp_blend',pnew),('baseline',r['pb'])]:
        pred=v.rank(candidates,r['pc'],score)
        result=submission_frame(sample,test,train,b.IDS[s['order']],pred)
        dest=run/f'submission_{name}.csv'
        result.to_csv(dest,index=False)
        print('WROTE',dest,'rows',len(result),flush=True)
    (run/'submission_info.json').write_text(json.dumps(dict(
        gallery_photos=len(train),test_queries=len(test),method='fixed 50/50 MLP blend',
        checkpoints='Frozen baseline, verifier and calibrators from validation experiment; no refitting',
        caveat='Full-gallery distribution differs from calibration/validation. No leaderboard improvement is established.'),indent=2))


if __name__=='__main__':
    with threadpool_limits(limits=4,user_api='blas'):main()
